# Add Custom Widgets to your Perspective Forms - Version 1.0.0

This resource was created to show other developers how to create their own widgets for use in Perspective views.

## Installation

### Custom Instructions
**Recognition**
I want to thank my colleague Aymar&uacute; Castillo for all his work in making this piece for it was truly a challenge to make it all happen.
**Installation Instructions**
Extract the **ignition-exchange.zip** file contents in your home drive.
Make sure to have JDK 11 installed.
**Eclipse instructions.**
Under File -&gt; Import, select existing projects into workspace and open the ignition-exchange folder.
**IntelliJ instructions**
Click on File -&gt; Project Structure and click on Modules on your left.  Click on the "+" button and select "Import Module".  Again select the ignition-exchange folder and open.
In the terminal, cd into the widget-module folder and execute: ./gradlew clean build . In the build directory there should be a file called MACAutoWidget.unsigned.modl, which is the module file you should use in the admin console to install the module.
The docker image has the necessary parameters to allow the installation of unsigned modules.
For further instructions / notes be sure to read the README.md file.
**Docker**
For convenience there is a docker file (unzip the docker-igntion.zip file) for use with docker compose.  In order to start an Ignition instance just go to where ever you extracted the contents and in the CLI (terminal) type "**docker compose up -d**".  The username and password is: admin/password.
Once it is up, in your browser proceed to: **http://localhost:9088/**
In the admin console restore the backup with the file **docker-test_Ignition-backup** provided above.  There is only one view showcasing the Gauge Widget and its variants.
The source code is also on GitHub at https://github.com/macautoinc/ignition-exchange 

### Common Instructions

**Gateway Backups (.gwbk)**  
Gateway backups are all inclusive and backup everything relating to an Ignition installation while Project exports are simply a backup of individual projects. Restoring a Gateway backup is just as easy as backing it up and can also be done from the Gateway Webpage.

When you perform a Gateway Restore, ALL of the server's current configuration will be permanently lost! Restoring a Gateway backup overwrites all of the existing settings including your projects. There is no merge option for a Gateway backup. We recommend you always make a backup of the existing server immediately before performing a Gateway Restore.
The Gateway restore is located in:
Ignition Gateway > Configuration > System >Backup/Restore > Restore Tab

**Project (.zip/.proj)**  
Project backup and restoring from a project backup is referred to as Project Export and Import. Projects are exported individually, and only include project-specific elements visible in the Project Browser in the Ignition Designer. They do not include Gateway resources, like database connections, Tag Providers, Tags, and images. The exported file (.zip or .proj) is used to restore / import a project.

.zip = Ignition 8+
.proj = Ignition 7+

There are two primary ways to export and import a project:

Gateway Webpage - exports and imports the entire project.
Designer -  exports and imports only those resources that are selected.

When you restore / import a project from an exported file in the Gateway Webpage, it will be merged into your existing Gateway.

The import is located in:
Ignition Gateway > Configuration > System > Projects > Import Project Link

If there is a naming collision, you have the option of renaming the project or overwriting the project. Project exports can also be restored / imported in the Designer. Once the Designer is opened you can choose File > Import from the menu. This will even allow you to select which parts of the project import you want to include and will merge them into the currently open project.

### Requirements

## Release Notes
Initial Commit

## Authors and Acknowledgment
Built for the [Ignition Exchange](https://inductiveautomation.com/exchange) by Jose Moya

## Support
View [Add Custom Widgets to your Perspective Forms](https://inductiveautomation.com/exchange/2631) for more information, and other [versions](https://inductiveautomation.com/exchange/2631/versions)

## License
+ [MIT](https://choosealicense.com/licenses/mit/)
+ [Terms & Conditions](https://inductiveautomation.com/exchange/terms)
+ [Acceptable Use](https://inductiveautomation.com/exchange/use)
